#ifndef E_WIDGET_CSEL_H
#define E_WIDGET_CSEL_H

Evas_Object *e_widget_csel_add(Evas *evas, E_Color *color, Eina_Bool alpha_enabled);

#endif
