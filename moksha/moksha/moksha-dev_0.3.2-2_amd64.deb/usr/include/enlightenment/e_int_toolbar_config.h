#ifdef E_TYPEDEFS
#else
#ifndef E_INT_TOOLBAR_CONFIG_H
#define E_INT_TOOLBAR_CONFIG_H

EAPI void e_int_toolbar_config(E_Toolbar *tbar);

#endif
#endif
