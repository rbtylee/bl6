#ifdef E_TYPEDEFS
#else
#ifndef E_INT_CONFIG_MODULES_H
#define E_INT_CONFIG_MODULES_H

EAPI E_Config_Dialog *e_int_config_modules(E_Container *con, const char *params);

#endif
#endif
