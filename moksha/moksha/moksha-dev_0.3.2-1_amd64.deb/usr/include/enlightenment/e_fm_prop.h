#ifdef E_TYPEDEFS
#else
#ifndef E_FM_PROP_H
#define E_FM_PROP_H

EAPI E_Config_Dialog *e_fm_prop_file(E_Container *con, E_Fm2_Icon *ic);

#endif
#endif
