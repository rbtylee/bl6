#ifdef E_TYPEDEFS
#else
#ifndef E_INT_BORDER_PROP_H
#define E_INT_BORDER_PROP_H

E_API void e_int_client_prop(E_Client *ec);

#endif
#endif
