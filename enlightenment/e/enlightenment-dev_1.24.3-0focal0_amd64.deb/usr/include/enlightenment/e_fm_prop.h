#ifdef E_TYPEDEFS
#else
#ifndef E_FM_PROP_H
#define E_FM_PROP_H

E_API E_Config_Dialog *e_fm_prop_file(E_Fm2_Icon *ic);

#endif
#endif
