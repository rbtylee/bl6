#ifdef E_TYPEDEFS
#else
#ifndef E_WIDGET_LABEL_H
#define E_WIDGET_LABEL_H

E_API Evas_Object *e_widget_label_add(Evas *evas, const char *label);
E_API void e_widget_label_text_set(Evas_Object *obj, const char *text);

#endif
#endif
