#ifdef E_TYPEDEFS
#else
#ifndef E_TEST_H
#define E_TEST_H

E_API void e_test(void);

#endif
#endif
