#ifdef E_TYPEDEFS
#else
#ifndef E_INT_BORDER_REMEMBER_H
#define E_INT_BORDER_REMEMBER_H

E_API void e_int_client_remember(E_Client *ec);
E_API E_Config_Dialog *e_int_client_remember_edit(E_Remember *rem);

#endif
#endif
