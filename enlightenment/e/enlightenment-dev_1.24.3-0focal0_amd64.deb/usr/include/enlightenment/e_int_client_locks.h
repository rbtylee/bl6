#ifdef E_TYPEDEFS
#else
#ifndef E_INT_BORDER_LOCKS_H
#define E_INT_BORDER_LOCKS_H

E_API void e_int_client_locks(E_Client *ec);

#endif
#endif
