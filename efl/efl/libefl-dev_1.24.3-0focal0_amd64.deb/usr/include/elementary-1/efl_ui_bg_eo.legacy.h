#ifndef _EFL_UI_BG_EO_LEGACY_H_
#define _EFL_UI_BG_EO_LEGACY_H_

#ifndef _EFL_UI_BG_EO_CLASS_TYPE
#define _EFL_UI_BG_EO_CLASS_TYPE

typedef Eo Efl_Ui_Bg;

#endif

#ifndef _EFL_UI_BG_EO_TYPES
#define _EFL_UI_BG_EO_TYPES


#endif

#endif
