#ifndef _ECORE_CON_EET_CLIENT_OBJ_EO_H_
#define _ECORE_CON_EET_CLIENT_OBJ_EO_H_

#ifndef _ECORE_CON_EET_CLIENT_OBJ_EO_CLASS_TYPE
#define _ECORE_CON_EET_CLIENT_OBJ_EO_CLASS_TYPE

typedef Eo Ecore_Con_Eet_Client_Obj;

#endif

#ifndef _ECORE_CON_EET_CLIENT_OBJ_EO_TYPES
#define _ECORE_CON_EET_CLIENT_OBJ_EO_TYPES


#endif
/** Ecore Connection Eet Client class.
 *
 * @ingroup Ecore_Con_Eet_Client_Obj
 */
#define ECORE_CON_EET_CLIENT_OBJ_CLASS ecore_con_eet_client_obj_class_get()

EWAPI const Efl_Class *ecore_con_eet_client_obj_class_get(void);

#endif
