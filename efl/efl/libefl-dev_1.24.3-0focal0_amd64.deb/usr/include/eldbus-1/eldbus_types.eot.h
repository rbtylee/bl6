#ifndef _ELDBUS_TYPES_EOT_H_
#define _ELDBUS_TYPES_EOT_H_

#ifndef _ELDBUS_TYPES_EOT_TYPES
#define _ELDBUS_TYPES_EOT_TYPES


#endif

#endif
