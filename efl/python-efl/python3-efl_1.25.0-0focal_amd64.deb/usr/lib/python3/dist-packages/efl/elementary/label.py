from . import Label

from . import ELM_WRAP_NONE
from . import ELM_WRAP_CHAR
from . import ELM_WRAP_WORD
from . import ELM_WRAP_MIXED

from . import ELM_LABEL_SLIDE_MODE_NONE
from . import ELM_LABEL_SLIDE_MODE_AUTO
from . import ELM_LABEL_SLIDE_MODE_ALWAYS
