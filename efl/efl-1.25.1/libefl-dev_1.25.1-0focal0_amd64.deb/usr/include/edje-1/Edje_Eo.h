#include <Efl.h>

#include "efl_layout_calc.eo.h"
#include "efl_layout_signal.eo.h"
#include "efl_layout_group.eo.h"
#include "efl_canvas_layout.eo.h"
#include "edje_edit_eo.h"

#include <efl_canvas_layout_types.eot.h>

#include "efl_canvas_layout_part_type_provider.eo.h"
#include "efl_canvas_layout_part.eo.h"
#include "efl_canvas_layout_part_box.eo.h"
#include "efl_canvas_layout_part_table.eo.h"
#include "efl_canvas_layout_part_swallow.eo.h"
#include "efl_canvas_layout_part_text.eo.h"
#include "efl_canvas_layout_part_external.eo.h"
